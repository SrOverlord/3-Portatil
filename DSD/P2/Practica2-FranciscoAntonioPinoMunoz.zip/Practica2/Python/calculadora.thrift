service Calculadora{
   void ping();
   double sumar      (1:double operador1, 2:double operador2);
   double restar     (1:double operador1, 2:double operador2);
   double multiplicar(1:double operador1, 2:double operador2);
   double dividir    (1:double operador1, 2:double operador2);
}
